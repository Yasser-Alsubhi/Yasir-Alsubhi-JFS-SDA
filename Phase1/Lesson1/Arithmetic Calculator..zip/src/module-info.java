module ph1L1calc {
}